import React from "react";

function Footer () {
var CurrYear = new Date().getFullYear();
return (
<div>
<footer>
<p>Copyright @ {CurrYear}</p>
</footer>
</div>
);
}

export default Footer;


