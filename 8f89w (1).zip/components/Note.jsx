import React from "react";

function Note() {
  <div classname = "note">
    <h1>Javascript and React.js</h1>
    <p>This bootcamp is Awesome and so interactive session and I learn so much things to ths
this bootcamp so I thank you so much to sir</p>
</div>
}

export default Note;
